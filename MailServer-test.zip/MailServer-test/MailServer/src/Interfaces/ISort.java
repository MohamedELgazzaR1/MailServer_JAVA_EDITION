package Interfaces;

public interface ISort {

}
