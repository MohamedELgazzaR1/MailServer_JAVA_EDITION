package Interfaces;

import java.io.File;

public interface IFolder {
	public File get();
}
