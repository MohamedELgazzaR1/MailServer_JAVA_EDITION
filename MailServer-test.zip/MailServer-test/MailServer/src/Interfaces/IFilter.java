package Interfaces;

public interface IFilter {

}
